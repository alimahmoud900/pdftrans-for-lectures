package app.pdftrans.pdf

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import app.pdftrans.*
import app.pdftrans.engine.Engine
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

/** Kotlin port of pdftrans.translate_pdf(): extract -> translate -> render. */
class PdfTranslator(private val ctx: Context) {
    private val fonts = FontProvider(ctx)

    suspend fun run(
        src: File, dst: File, opts: Options, engine: Engine,
        progress: (Stage, Int, Int) -> Unit
    ): Report = withContext(Dispatchers.Default) { doRun(src, dst, opts, engine, progress) }

    private suspend fun doRun(
        src: File, dst: File, opts: Options, engine: Engine,
        progress: (Stage, Int, Int) -> Unit
    ): Report {
        val t0 = SystemClock.elapsedRealtime()
        opts.validate()
        val rep = Report()
        val doc = openPdf(src)
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var recognizer: TextRecognizer? = null
        val tmp = File(ctx.cacheDir, "overlay.pdf")

        fun rendererOrOpen(): PdfRenderer {
            renderer?.let { return it }
            val fd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
            pfd = fd
            return PdfRenderer(fd).also { renderer = it }
        }

        try {
            rep.pagesTotal = doc.numberOfPages
            val wanted = parsePages(opts.pages, doc.numberOfPages)
            engine.prepare()

            // ---- 1. extraction (OCR for scanned pages) ---------------------------------
            val pageLines = HashMap<Int, List<Line>>()
            for ((n, pno) in wanted.withIndex()) {
                currentCoroutineContext().ensureActive()
                progress(Stage.EXTRACT, n + 1, wanted.size)
                val page = doc.getPage(pno)
                var (lines, rot) = extractPageLines(doc, pno)
                rep.rotatedWords += rot
                val textLen = lines.sumOf { l -> l.text.count { !it.isWhitespace() } }
                if (textLen < 25 && pageHasImage(page)) {
                    if (opts.ocr) {
                        try {
                            val rec = recognizer ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                .also { recognizer = it }
                            lines = ocrLines(rendererOrOpen(), pno, rec)
                            rep.ocrPages.add(pno + 1)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            rep.scannedUnprocessed.add(pno + 1)
                        }
                    } else {
                        rep.scannedUnprocessed.add(pno + 1)
                    }
                }
                if (opts.mode != Mode.PARAGRAPH && page.rotation != 0) {
                    rep.rotatedPages++
                    lines = emptyList()
                }
                pageLines[pno] = lines
            }

            // ---- 2. choose the segments to translate ----------------------------------
            val paras = ArrayList<Para>()
            val lineSegs = ArrayList<Line>()
            val texts = ArrayList<String>()
            val index = ArrayList<Int>()               // segment position of every translatable text
            if (opts.mode == Mode.PARAGRAPH) {
                for (pno in wanted) paras += buildParagraphs(pageLines[pno] ?: emptyList(), pno + 1)
                classifyParagraphs(paras)
                paras.forEachIndexed { i, p ->
                    val t = stripBullet(p.text)
                    if (needsTranslation(t)) { texts.add(t); index.add(i) }
                }
            } else {
                for (pno in wanted) lineSegs += pageLines[pno] ?: emptyList()
                lineSegs.forEachIndexed { i, l ->
                    if (needsTranslation(l.text)) { texts.add(l.text); index.add(i) }
                }
            }
            rep.segments = texts.size
            if (texts.isEmpty()) throw PdfTransException("no_text")

            // ---- 3. translate ---------------------------------------------------------
            val translated = engine.translate(texts) { d, t -> progress(Stage.TRANSLATE, d, t) }
            rep.failedSegments = engine.failed

            // ---- 4. render ------------------------------------------------------------
            currentCoroutineContext().ensureActive()
            if (opts.mode == Mode.PARAGRAPH) {
                val trans = HashMap<Int, String>()
                index.forEachIndexed { j, i -> trans[i] = translated[j] }
                val cb = doc.getPage(wanted[0]).cropBox
                var w = cb.width
                var h = cb.height
                if (doc.getPage(wanted[0]).rotation % 180 != 0) { val x = w; w = h; h = x }
                renderParagraphs(fonts, opts, paras, trans, w, h, dst) { d, t -> progress(Stage.RENDER, d, t) }
            } else {
                val trans = HashMap<Line, String>()
                index.forEachIndexed { j, i -> trans[lineSegs[i]] = translated[j] }
                renderOverlay(
                    fonts, opts, src, doc, wanted, pageLines, trans, rendererOrOpen(),
                    rep.ocrPages, tmp, dst, rep
                ) { d, t -> progress(Stage.RENDER, d, t) }
            }
            rep.pagesDone = wanted.size
        } finally {
            try { recognizer?.close() } catch (e: Exception) { }
            try { renderer?.close() } catch (e: Exception) { }
            try { pfd?.close() } catch (e: Exception) { }
            doc.close()
            tmp.delete()
        }
        rep.seconds = (SystemClock.elapsedRealtime() - t0) / 1000.0
        return rep
    }
}
