package app.pdftrans

import android.content.Context
import java.io.File
import java.util.Locale

enum class Mode { SMART, LINE, PARAGRAPH }
enum class EngineKind { ONDEVICE, GOOGLE, MYMEMORY, LIBRE }
enum class Align { RIGHT, CENTER, LEFT }
enum class Stage { EXTRACT, TRANSLATE, RENDER }
enum class Screen { HOME, SETUP, RUN, SETTINGS }
enum class ModelStatus { UNKNOWN, MISSING, READY, DOWNLOADING }

/** Fonts are SIL-OFL, fetched into assets/fonts by scripts/fetch_fonts.sh. */
enum class FontKey(val label: String, val regular: String, val bold: String) {
    AMIRI("Amiri", "Amiri-Regular.ttf", "Amiri-Bold.ttf"),
    PLEX("IBM Plex Sans Arabic", "IBMPlexSansArabic-Regular.ttf", "IBMPlexSansArabic-Bold.ttf"),
    SCHEHERAZADE("Scheherazade New", "ScheherazadeNew-Regular.ttf", "ScheherazadeNew-Bold.ttf")
}

/** Error shown to the user. [code] is mapped to a localized sentence in ui/Strings.kt. */
class PdfTransException(val code: String, val detail: String = "") :
    Exception(if (detail.isEmpty()) code else "$code: $detail")

const val DEFAULT_COLOR = "#0b3d91"
val NAMED_COLORS = linkedMapOf(
    "black" to "#000000", "blue" to DEFAULT_COLOR, "red" to "#b00020", "green" to "#1b5e20",
    "purple" to "#4a148c", "orange" to "#e65100", "gray" to "#555555", "grey" to "#555555"
)

fun parseColor(value: String): String {
    var v = value.trim().lowercase()
    v = NAMED_COLORS[v] ?: v
    if (Regex("#?[0-9a-f]{6}").matches(v)) return if (v.startsWith("#")) v else "#$v"
    if (Regex("#?[0-9a-f]{3}").matches(v)) {
        v = v.trimStart('#')
        return "#" + v.map { "$it$it" }.joinToString("")
    }
    throw PdfTransException("bad_color", value)
}

data class Options(
    val mode: Mode = Mode.SMART,
    val font: FontKey = FontKey.AMIRI,
    val size: Float? = null,          // line: fixed (12) / smart: upper bound / paragraph: body size
    val color: String? = null,        // null = default (smart picks per line from the background)
    val bold: Boolean = false,
    val align: Align = Align.RIGHT,
    val pages: String? = null,        // "1-10,15,20-"  (1-based)
    val ocr: Boolean = true,
    val minSize: Float = 5f
) {
    fun validate() {
        size?.let { if (it < 3f || it > 72f) throw PdfTransException("bad_size") }
        color?.let { parseColor(it) }
    }
}

class Report {
    var pagesTotal = 0
    var pagesDone = 0
    var segments = 0
    val ocrPages = mutableListOf<Int>()
    val scannedUnprocessed = mutableListOf<Int>()
    var rotatedPages = 0
    var rotatedWords = 0
    var tightLines = 0
    var expandedPages = 0
    var failedSegments = 0
    var seconds = 0.0
}

/** "1-3,7,10-" -> zero-based page indices */
fun parsePages(spec: String?, count: Int): List<Int> {
    if (spec.isNullOrBlank()) return (0 until count).toList()
    val out = sortedSetOf<Int>()
    val range = Regex("""(\d*)\s*-\s*(\d*)""")
    for (raw in spec.split(",")) {
        val part = raw.trim()
        if (part.isEmpty()) continue
        val a: Int
        val b: Int
        val m = range.matchEntire(part)
        if (m != null) {
            a = (m.groupValues[1].ifEmpty { "1" }).toIntOrNull() ?: throw PdfTransException("bad_range", part)
            b = (m.groupValues[2].ifEmpty { count.toString() }).toIntOrNull() ?: throw PdfTransException("bad_range", part)
        } else if (part.all { it.isDigit() }) {
            a = part.toIntOrNull() ?: throw PdfTransException("bad_range", part)
            b = a
        } else throw PdfTransException("bad_range", part)
        if (a < 1 || b < a) throw PdfTransException("bad_range", part)
        for (i in a..minOf(b, count)) out.add(i - 1)
    }
    if (out.isEmpty()) throw PdfTransException("empty_pages", spec)
    return out.toList()
}

private val LIGATURES = mapOf("\uFB00" to "ff", "\uFB01" to "fi", "\uFB02" to "fl", "\uFB03" to "ffi", "\uFB04" to "ffl")

fun cleanText(s: String): String {
    var t = s
    for ((k, v) in LIGATURES) t = t.replace(k, v)
    t = t.replace("\u00AD", "").replace('\u00A0', ' ')
    return t.replace(Regex("\\s+"), " ").trim()
}

private val LATIN_WORD = Regex("[A-Za-z]{2,}")

/** False for page numbers, formulas, URLs-only and text that is already Arabic. */
fun needsTranslation(text: String): Boolean {
    if (!LATIN_WORD.containsMatchIn(text)) return false
    val arabic = text.count { it in '\u0600'..'\u06FF' }
    val latin = text.count { it in 'A'..'Z' || it in 'a'..'z' }
    return latin > arabic
}

// ------------------------------------------------------------------ settings

data class AppSettings(
    val lang: String = if (Locale.getDefault().language == "ar") "ar" else "en",
    val theme: String = "system",              // system | light | dark
    val engine: EngineKind = EngineKind.ONDEVICE,
    val lastOnline: EngineKind = EngineKind.GOOGLE,
    val mode: Mode = Mode.SMART,
    val font: FontKey = FontKey.AMIRI,
    val size: Float? = null,
    val color: String? = null,
    val bold: Boolean = false,
    val align: Align = Align.RIGHT,
    val ocr: Boolean = true,
    val allowGoogle: Boolean = false,
    val libreUrl: String = "",
    val libreKey: String = "",
    val memoryEmail: String = ""
)

data class PdfInfo(val file: File, val name: String, val pages: Int, val sizeMb: Double, val scanned: Int)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("pdftrans", Context.MODE_PRIVATE)

    private inline fun <reified E : Enum<E>> enumOf(key: String, def: E): E =
        runCatching { enumValueOf<E>(sp.getString(key, "") ?: "") }.getOrDefault(def)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            lang = sp.getString("lang", null) ?: d.lang,
            theme = sp.getString("theme", d.theme) ?: d.theme,
            engine = enumOf("engine", d.engine),
            lastOnline = enumOf("lastOnline", d.lastOnline),
            mode = enumOf("mode", d.mode),
            font = enumOf("font", d.font),
            size = sp.getFloat("size", -1f).takeIf { it > 0 },
            color = sp.getString("color", null),
            bold = sp.getBoolean("bold", d.bold),
            align = enumOf("align", d.align),
            ocr = sp.getBoolean("ocr", d.ocr),
            allowGoogle = sp.getBoolean("allowGoogle", false),
            libreUrl = sp.getString("libreUrl", "") ?: "",
            libreKey = sp.getString("libreKey", "") ?: "",
            memoryEmail = sp.getString("memoryEmail", "") ?: ""
        )
    }

    fun save(s: AppSettings) {
        sp.edit()
            .putString("lang", s.lang).putString("theme", s.theme)
            .putString("engine", s.engine.name).putString("lastOnline", s.lastOnline.name)
            .putString("mode", s.mode.name).putString("font", s.font.name)
            .putFloat("size", s.size ?: -1f).putString("color", s.color)
            .putBoolean("bold", s.bold).putString("align", s.align.name)
            .putBoolean("ocr", s.ocr).putBoolean("allowGoogle", s.allowGoogle)
            .putString("libreUrl", s.libreUrl).putString("libreKey", s.libreKey)
            .putString("memoryEmail", s.memoryEmail)
            .apply()
    }
}
