package app.pdftrans.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import app.pdftrans.*
import com.tom_roush.pdfbox.multipdf.LayerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

private val INK_BLUE = Color.parseColor("#0b3d91")
private val INK_LIGHT = Color.parseColor("#ffd54f")

// ------------------------------------------------------------------ text layout

private fun paintFor(fonts: FontProvider, o: Options, size: Float, color: Int) =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = fonts.typeface(o.font, o.bold)
        textSize = size
        this.color = color
    }

/** Shaped, bidi-aware Arabic layout (Android's text engine handles joining and RTL). */
private fun arabicLayout(text: String, width: Float, paint: TextPaint, align: Align): StaticLayout {
    val a = when (align) {
        Align.RIGHT -> Layout.Alignment.ALIGN_NORMAL       // start edge of an RTL paragraph = right
        Align.LEFT -> Layout.Alignment.ALIGN_OPPOSITE
        Align.CENTER -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(text, 0, text.length, paint, max(8, width.toInt()))
        .setAlignment(a)
        .setTextDirection(TextDirectionHeuristics.RTL)
        .setLineSpacing(0f, 1.25f)
        .setIncludePad(false)
        .build()
}

private class Measurer(private val fonts: FontProvider, private val o: Options) {
    private val cache = HashMap<String, Float>()
    fun height(text: String, width: Float, size: Float): Float =
        cache.getOrPut("${text.length}:${text.hashCode()}:${width.toInt()}:${(size * 100).toInt()}") {
            arabicLayout(text, width, paintFor(fonts, o, size, Color.BLACK), o.align).height.toFloat()
        }
}

// ------------------------------------------------------------- page analysis

private fun gray(p: Int): Int =
    (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000

/**
 * Pixel scan of a rendered page. A scan-line is "blank" when every pixel in the text columns
 * has (almost) the same colour. Pages are only cut on blank scan-lines, so no glyph is sliced.
 */
private class Ink(bmp: Bitmap, private val k: Float, x0: Float, x1: Float, tol: Int) {
    private val blank = BooleanArray(bmp.height)
    private val heightPt = bmp.height / k

    init {
        val a = max(0, (x0 * k).toInt())
        val b = min(bmp.width, (x1 * k).toInt() + 1)
        val n = max(0, b - a)
        val row = IntArray(max(n, 1))
        for (y in 0 until bmp.height) {
            if (n == 0) { blank[y] = true; continue }
            bmp.getPixels(row, 0, n, a, y, n, 1)
            var mn = 255
            var mx = 0
            for (i in 0 until n) {
                val g = gray(row[i])
                if (g < mn) mn = g
                if (g > mx) mx = g
            }
            blank[y] = mx - mn <= tol
        }
    }

    private fun px(yPt: Float) = max(0, min(blank.size - 1, (yPt * k).toInt()))

    /** Middle (pt) of the first run of blank scan-lines that starts inside [yPt, limitPt]. */
    fun firstBlank(yPt: Float, limitPt: Float): Float? {
        for (y in px(yPt)..px(limitPt)) {
            if (blank[y]) {
                var end = y
                while (end + 1 < blank.size && blank[end + 1]) end++
                val run = min(end + 1 - y, (6 * k).toInt())
                return (y + run / 2f) / k
            }
        }
        return null
    }

    fun nextInk(yPt: Float): Float {
        for (y in px(yPt) until blank.size) if (!blank[y]) return y / k
        return heightPt
    }
}

private fun regionLum(bmp: Bitmap, k: Float, l: Line): Int {
    val x0 = max(0, (l.x0 * k).toInt()); val x1 = min(bmp.width - 1, (l.x1 * k).toInt())
    val y0 = max(0, (l.top * k).toInt()); val y1 = min(bmp.height - 1, (l.bottom * k).toInt())
    if (x1 <= x0 || y1 <= y0) return 255
    var sum = 0L
    var n = 0
    var y = y0
    while (y <= y1) {
        var x = x0
        while (x <= x1) { sum += gray(bmp.getPixel(x, y)); n++; x += 3 }
        y += 3
    }
    return if (n == 0) 255 else (sum / n).toInt()
}

private fun renderBitmap(renderer: PdfRenderer, pno: Int, pw: Float, ph: Float, k: Float): Bitmap {
    val bmp = Bitmap.createBitmap(max(1, (pw * k).toInt()), max(1, (ph * k).toInt()), Bitmap.Config.ARGB_8888)
    bmp.eraseColor(Color.WHITE)
    val p = renderer.openPage(pno)
    try { p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) } finally { p.close() }
    return bmp
}

private fun rowGroups(lines: List<Line>): List<List<Line>> {
    val groups = ArrayList<MutableList<Line>>()
    for (l in lines.sortedBy { (it.top + it.bottom) / 2 }) {
        val mid = (l.top + l.bottom) / 2
        val g = groups.lastOrNull()
        if (g != null) {
            val gmid = g.map { (it.top + it.bottom) / 2 }.average().toFloat()
            if (abs(mid - gmid) <= 0.5f * max(l.height, g[0].height)) { g.add(l); continue }
        }
        groups.add(mutableListOf(l))
    }
    return groups
}

private fun freeSpaceBelow(line: Line, lines: List<Line>, ph: Float): Float {
    var nxt = ph - 14f
    for (o in lines) {
        if (o === line || o.top < line.bottom - 1f) continue
        if (min(o.x1, line.blockX1) - max(o.x0, line.x0) > 4f) nxt = min(nxt, o.top)
    }
    return max(0f, nxt - line.bottom)
}

// ------------------------------------------------------------ overlay modes

private class Entry(
    val oldY: Float, val x0: Float, val x1: Float, val h: Float, val text: String,
    val size: Float, val color: Int, val inline: Boolean, val gap: Float = 99f
)

private class Cut(val y: Float, val extra: Float, val band: Int)
private class PagePlan(val pno: Int, val cuts: List<Cut>)

/**
 * "smart" and "line" modes: the original pages are kept; the Arabic is drawn on a transparent
 * overlay (Android's text engine = correct Arabic shaping) and merged on top with PDFBox.
 * In smart mode pages are cut on blank scan-lines and made taller so nothing overlaps.
 */
suspend fun renderOverlay(
    fonts: FontProvider, o: Options, srcFile: File, srcDoc: PDDocument, wanted: List<Int>,
    pageLines: Map<Int, List<Line>>, trans: Map<Line, String>, renderer: PdfRenderer,
    ocrPages: List<Int>, tmpOverlay: File, dst: File, rep: Report, progress: (Int, Int) -> Unit
) {
    val smart = o.mode == Mode.SMART
    val fixed = o.size ?: 12f
    val userColor = o.color?.let { Color.parseColor(parseColor(it)) }
    val meas = Measurer(fonts, o)
    val ov = PdfDocument()
    val plans = ArrayList<PagePlan>()

    fun targetSize(l: Line): Float {
        if (!smart) return fixed
        var s = l.size * 0.9f
        o.size?.let { s = min(s, it) }
        return max(s, o.minSize)
    }

    for ((n, pno) in wanted.withIndex()) {
        currentCoroutineContext().ensureActive()
        progress(n + 1, wanted.size)
        val cb = srcDoc.getPage(pno).cropBox
        val pw = cb.width
        val ph = cb.height
        val lines = pageLines[pno] ?: emptyList()
        val translated = lines.filter { trans.containsKey(it) }

        val k = min(2f, 3200f / max(pw, ph))
        val bmp: Bitmap? = if (translated.isNotEmpty() && smart) renderBitmap(renderer, pno, pw, ph, k) else null

        fun colorOf(l: Line): Int = userColor
            ?: if (smart && bmp != null) (if (regionLum(bmp, k, l) >= 140) INK_BLUE else INK_LIGHT) else INK_BLUE

        val entries = ArrayList<Entry>()
        val cuts = ArrayList<Cut>()
        var ink: Ink? = null
        if (bmp != null) {
            val xs0 = lines.minOf { it.x0 } - 3f
            val xs1 = lines.maxOf { it.x1 } + 3f
            ink = Ink(bmp, k, xs0, xs1, if ((pno + 1) in ocrPages) 40 else 1)
        }

        for (grp in rowGroups(lines)) {
            val tl = grp.filter { trans.containsKey(it) }.sortedBy { it.x0 }
            if (tl.isEmpty()) continue
            val rects = tl.mapIndexed { i, l ->
                val x0 = max(l.blockX0, 10f)
                val width = max(max(l.blockX1 - l.blockX0, (l.x1 - l.x0) * 1.3f), 60f)
                var x1 = min(x0 + width, pw - 10f)
                if (i + 1 < tl.size && tl[i + 1].x0 > l.x0 + 10f) x1 = min(x1, max(tl[i + 1].x0 - 5f, l.x1))
                Pair(x0, max(x1, x0 + 20f))
            }

            var cut: Float? = null
            if (ink != null) {
                val hgt = grp.maxOf { it.height }
                val base = grp.maxOf { it.bottom }
                val mid = grp.map { (it.top + it.bottom) / 2 }.average().toFloat()
                cut = ink.firstBlank(max(mid, base - 0.45f * hgt), base + 0.7f * hgt)
            }

            if (cut != null && ink != null) {
                val avail = max(0f, min(ink.nextInk(cut), ph - 4f) - cut - 0.5f)
                fun need(scale: Float): Float = tl.indices.maxOf { i ->
                    val s = targetSize(tl[i]) * scale
                    meas.height(trans.getValue(tl[i]), rects[i].second - rects[i].first, s) + 0.35f * s
                } + 1f

                var scale = 1f
                var extra = 0f
                var h = need(1f)
                if (h > avail) {
                    var fitted: Float? = null
                    if (smart) {
                        for (sc in listOf(0.9f, 0.8f, 0.7f)) {
                            if (tl.all { targetSize(it) * sc >= o.minSize - 0.01f }) {
                                val h2 = need(sc)
                                if (h2 <= avail) { fitted = sc; h = h2; break }
                            }
                        }
                    }
                    if (fitted != null) scale = fitted
                    else {
                        extra = h - avail + 1f
                        val bx = bmp!!.getPixel(min(1, bmp.width - 1), max(0, min(bmp.height - 1, (cut * k).toInt())))
                        cuts.add(Cut(cut, extra, bx))
                    }
                }
                for (i in tl.indices) {
                    entries.add(Entry(cut, rects[i].first, rects[i].second, h + 2f, trans.getValue(tl[i]),
                        targetSize(tl[i]) * scale, colorOf(tl[i]), false))
                }
            } else {
                // no blank line below it (multi-column text, tables, figures) or not expanding: draw in place
                for (i in tl.indices) {
                    val l = tl[i]
                    val s = targetSize(l)
                    val gap = freeSpaceBelow(l, lines, ph)
                    val h = if (smart) min(max(gap, o.minSize * 1.5f), s * 1.3f * 4f) else s * 1.3f * 4f
                    entries.add(Entry(l.bottom, rects[i].first, rects[i].second, h, trans.getValue(l), s,
                        colorOf(l), true, gap))
                }
            }
        }
        bmp?.recycle()

        cuts.sortBy { it.y }
        val total = cuts.sumOf { it.extra.toDouble() }.toFloat()
        val fh = ph + total
        plans.add(PagePlan(pno, cuts))
        if (cuts.isNotEmpty()) rep.expandedPages++

        // ---- draw the translations on the overlay page
        val page = ov.startPage(PdfDocument.PageInfo.Builder(ceil(pw).toInt(), ceil(fh).toInt(), n + 1).create())
        val canvas = page.canvas
        for (e in entries) {
            val shift = cuts.filter { it.y < e.oldY }.sumOf { it.extra.toDouble() }.toFloat()
            val y = e.oldY + shift + 0.4f
            val boxH = min(e.h, fh - y)
            val boxW = e.x1 - e.x0
            if (boxH < 3f || boxW < 8f) continue
            var size = e.size
            var layout = arabicLayout(e.text, boxW, paintFor(fonts, o, size, e.color), o.align)
            if (e.inline) {
                if (smart) {
                    while (layout.height > boxH && size > o.minSize) {
                        size = max(o.minSize, size * 0.92f)
                        layout = arabicLayout(e.text, boxW, paintFor(fonts, o, size, e.color), o.align)
                    }
                }
                if (layout.height > boxH + 0.5f || (smart && e.gap < o.minSize * 1.3f)) rep.tightLines++
            }
            canvas.save()
            canvas.translate(e.x0, y)
            layout.draw(canvas)
            canvas.restore()
        }
        ov.finishPage(page)
    }

    FileOutputStream(tmpOverlay).use { ov.writeTo(it) }
    ov.close()
    mergeOverlay(srcDoc, tmpOverlay, plans, dst)
}

private fun mergeOverlay(srcDoc: PDDocument, overlayFile: File, plans: List<PagePlan>, dst: File) {
    val ovDoc = PDDocument.load(overlayFile)
    val out = PDDocument()
    try {
        val lu = LayerUtility(out)
        for ((i, plan) in plans.withIndex()) {
            val srcPage = srcDoc.getPage(plan.pno)
            if (srcPage.rotation != 0) {          // overlay modes leave rotated pages untouched
                out.importPage(srcPage)
                continue
            }
            val cb = srcPage.cropBox
            val w = cb.width
            val h = cb.height
            val total = plan.cuts.sumOf { it.extra.toDouble() }.toFloat()
            val fh = h + total
            val form = lu.importPageAsForm(srcDoc, plan.pno)
            val ovForm = lu.importPageAsForm(ovDoc, i)
            val page = PDPage(PDRectangle(w, fh))
            out.addPage(page)
            PDPageContentStream(out, page).use { cs ->
                val bounds = listOf(0f) + plan.cuts.map { it.y } + listOf(h)
                var off = 0f
                for (j in 0 until bounds.size - 1) {
                    val a = bounds[j]
                    val b = bounds[j + 1]
                    if (b - a > 0.01f) {
                        cs.saveGraphicsState()
                        cs.addRect(0f, fh - (b + off), w, b - a)
                        cs.clip()
                        cs.transform(Matrix.getTranslateInstance(-cb.lowerLeftX, fh - off - cb.lowerLeftY - h))
                        cs.drawForm(form)
                        cs.restoreGraphicsState()
                    }
                    if (j < plan.cuts.size) {
                        val c = plan.cuts[j]
                        cs.setNonStrokingColor(Color.red(c.band), Color.green(c.band), Color.blue(c.band))
                        cs.addRect(0f, fh - (c.y + off + c.extra), w, c.extra)
                        cs.fill()
                        off += c.extra
                    }
                }
                cs.drawForm(ovForm)
            }
        }
        out.save(dst)
    } finally {
        out.close()
        ovDoc.close()
    }
}

// ------------------------------------------------------------ paragraph mode

private class Flow(private val doc: PdfDocument, private val pw: Int, private val ph: Int, private val margin: Float) {
    private var page: PdfDocument.Page? = null
    private var canvas: android.graphics.Canvas? = null
    private var y = margin
    private var count = 0
    private val bottom get() = ph - margin

    private fun newPage() {
        page?.let { doc.finishPage(it) }
        count++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, count).create())
        page = p; canvas = p.canvas; y = margin
    }

    fun place(layout: StaticLayout, spaceBefore: Float, spaceAfter: Float) {
        if (page == null) newPage()
        if (y > margin) y += spaceBefore
        var line = 0
        while (line < layout.lineCount) {
            val avail = bottom - y
            var last = line
            while (last < layout.lineCount && layout.getLineBottom(last) - layout.getLineTop(line) <= avail) last++
            if (last == line) {
                if (y > margin + 1f) { newPage(); continue }
                last = line + 1                                  // a single line taller than the page
            }
            val top = layout.getLineTop(line).toFloat()
            val bot = layout.getLineBottom(last - 1).toFloat()
            val c = canvas!!
            c.save()
            c.translate(margin, y - top)
            c.clipRect(0f, top, layout.width.toFloat(), bot)
            layout.draw(c)
            c.restore()
            y += bot - top
            line = last
            if (line < layout.lineCount) newPage()
        }
        y += spaceAfter
    }

    fun finish() { page?.let { doc.finishPage(it) }; page = null }
}

/** "paragraph" mode: the document is rebuilt, each English paragraph followed by its Arabic. */
suspend fun renderParagraphs(
    fonts: FontProvider, o: Options, paras: List<Para>, trans: Map<Int, String>,
    pw: Float, ph: Float, dst: File, progress: (Int, Int) -> Unit
) {
    val body = o.size ?: 12f
    val color = Color.parseColor(parseColor(o.color ?: DEFAULT_COLOR))
    val margin = 40f
    val contentW = (pw - 2 * margin).toInt()
    val doc = PdfDocument()
    val flow = Flow(doc, ceil(pw).toInt(), ceil(ph).toInt(), margin)
    val sans = Typeface.create("sans-serif", Typeface.NORMAL)
    val sansBold = Typeface.create("sans-serif", Typeface.BOLD)

    fun srcLayout(text: String, size: Float, bold: Boolean, col: Int, center: Boolean = false): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = if (bold) sansBold else sans; textSize = size; color = col }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, contentW)
            .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (center) TextDirectionHeuristics.FIRSTSTRONG_LTR else TextDirectionHeuristics.LTR)
            .setLineSpacing(0f, 1.2f).setIncludePad(false).build()
    }

    var lastPage = -1
    try {
        for ((i, p) in paras.withIndex()) {
            currentCoroutineContext().ensureActive()
            progress(i + 1, paras.size)
            if (p.page != lastPage) {
                flow.place(srcLayout("― ${p.page} ―", 8f, false, Color.parseColor("#999999"), center = true), 12f, 0f)
                lastPage = p.page
            }
            val heading = p.kind.startsWith("h")
            val srcSize = when (p.kind) { "h1" -> body * 1.2f; "h2" -> body * 1.08f; else -> body * 0.85f }
            flow.place(srcLayout(p.text, srcSize, heading, Color.parseColor("#4a4a4a")), 7f, 0f)
            val t = trans[i] ?: continue
            val scale = when (p.kind) { "h1" -> 1.35f; "h2" -> 1.2f; "h3" -> 1.08f; else -> 1f }
            val text = if (p.kind == "li") "\u200F•\u00A0$t" else t
            val tp = paintFor(fonts, o.copy(bold = o.bold || heading), body * scale, color)
            flow.place(arabicLayout(text, contentW.toFloat(), tp, o.align), 2f, 4f)
        }
        flow.finish()
        FileOutputStream(dst).use { doc.writeTo(it) }
    } finally {
        doc.close()
    }
}
