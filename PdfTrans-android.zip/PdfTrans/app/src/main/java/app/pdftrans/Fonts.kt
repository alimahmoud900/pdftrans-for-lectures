package app.pdftrans

import android.content.Context
import android.graphics.Typeface

/** Loads the bundled Arabic fonts for PDF output; falls back to Android's system Arabic font. */
class FontProvider(private val ctx: Context) {
    private val cache = HashMap<String, Typeface>()

    fun typeface(key: FontKey, bold: Boolean): Typeface = cache.getOrPut("${key.name}/$bold") {
        try {
            Typeface.createFromAsset(ctx.assets, "fonts/" + if (bold) key.bold else key.regular)
        } catch (e: Exception) {
            Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
    }
}
