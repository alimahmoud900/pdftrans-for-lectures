package app.pdftrans.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import app.pdftrans.PdfTransException
import app.pdftrans.cleanText
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognizer
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.tasks.await
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/** One horizontal line of text. Coordinates are PDF points, origin top-left. */
class Line(
    val text: String,
    val x0: Float, val x1: Float,
    val top: Float, val bottom: Float,
    val size: Float,
    val bold: Boolean
) {
    var block = 0
    var blockX0 = x0
    var blockX1 = x1
    val height get() = bottom - top
}

class Para(val text: String, val size: Float, val bold: Boolean, val page: Int) {
    var kind = "p"      // p | li | h1 | h2 | h3
}

fun openPdf(file: File): PDDocument {
    val doc = try {
        PDDocument.load(file)
    } catch (e: Exception) {
        val msg = e.message ?: ""
        if (e.javaClass.simpleName.contains("Password", true) || msg.contains("password", true))
            throw PdfTransException("password")
        throw PdfTransException("cannot_open", msg)
    }
    if (doc.numberOfPages == 0) {
        doc.close(); throw PdfTransException("empty_pdf")
    }
    return doc
}

fun pageHasImage(page: PDPage): Boolean = try {
    val res = page.resources
    res != null && res.xObjectNames.any { n -> try { res.getXObject(n) is PDImageXObject } catch (e: Exception) { false } }
} catch (e: Exception) {
    true
}

// ------------------------------------------------------- text from the PDF

private class WordCollector : PDFTextStripper() {
    val words = ArrayList<List<TextPosition>>()
    override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
        if (!textPositions.isNullOrEmpty()) words.add(ArrayList(textPositions))
    }
}

private class Word(val text: String, val x0: Float, val x1: Float, val base: Float, val size: Float, val bold: Boolean)

private fun isBold(tp: TextPosition): Boolean {
    val f = tp.font ?: return false
    val n = (f.name ?: "").lowercase()
    if ("bold" in n || "black" in n || "heavy" in n) return true
    return try {
        val d = f.fontDescriptor
        d != null && (d.fontWeight >= 700f || d.isForceBold)
    } catch (e: Exception) {
        false
    }
}

/** Returns (lines in reading order, number of rotated/vertical words that were skipped). */
fun extractPageLines(doc: PDDocument, pno: Int): Pair<List<Line>, Int> {
    val st = WordCollector()
    st.startPage = pno + 1
    st.endPage = pno + 1
    st.sortByPosition = false
    try {
        st.getText(doc)
    } catch (e: Exception) {
        return Pair(emptyList(), 0)
    }
    val pageRot = doc.getPage(pno).rotation.toFloat()
    var rotated = 0
    val words = ArrayList<Word>()
    for (tps in st.words) {
        val first = tps.first()
        val last = tps.last()
        val d = first.dir
        if (d != 0f && d != pageRot) { rotated++; continue }
        val text = cleanText(tps.joinToString("") { it.unicode ?: "" })
        if (text.isEmpty()) continue
        var size = tps.map { it.fontSizeInPt }.average().toFloat()
        if (size <= 0f) size = 10f
        words.add(
            Word(
                text, first.xDirAdj, last.xDirAdj + last.widthDirAdj, first.yDirAdj, size,
                tps.count { isBold(it) } > tps.size / 2
            )
        )
    }

    val lines = ArrayList<Line>()
    var cur = ArrayList<Word>()
    fun flush() {
        if (cur.isEmpty()) return
        val main = cur.maxByOrNull { it.text.length }!!
        val base = cur.map { it.base }.average().toFloat()
        val size = main.size
        lines.add(
            Line(
                cur.joinToString(" ") { it.text }, cur.first().x0, cur.last().x1,
                base - 0.80f * size, base + 0.22f * size, size, cur.count { it.bold } > cur.size / 2
            )
        )
        cur = ArrayList()
    }
    for (w in words) {
        if (cur.isNotEmpty()) {
            val p = cur.last()
            val ref = max(p.size, w.size)
            val sameRow = abs(w.base - p.base) <= 0.4f * ref
            val forward = w.x0 >= p.x1 - 0.5f * ref
            val near = w.x0 - p.x1 <= 2.2f * ref          // a wide gap = next column / table cell
            if (!(sameRow && forward && near)) flush()
        }
        cur.add(w)
    }
    flush()
    assignBlocks(lines)
    return Pair(lines, rotated)
}

/** Group neighbouring lines into text blocks (used for the width available to a translation). */
fun assignBlocks(lines: List<Line>) {
    var id = 0
    for (i in lines.indices) {
        if (i > 0) {
            val p = lines[i - 1]
            val l = lines[i]
            val fresh = l.top - p.bottom > 2.0f * l.size ||
                l.top < p.top - 0.5f * l.size ||
                abs(l.size - p.size) > 2f ||
                l.x0 > p.x1 + l.size || l.x1 < p.x0 - l.size
            if (fresh) id++
        }
        lines[i].block = id
    }
    for ((_, members) in lines.groupBy { it.block }) {
        val a = members.minOf { it.x0 }
        val b = members.maxOf { it.x1 }
        members.forEach { it.blockX0 = a; it.blockX1 = b }
    }
}

// ------------------------------------------------------------------- OCR

suspend fun ocrLines(renderer: PdfRenderer, pno: Int, recognizer: TextRecognizer, dpi: Int = 200): List<Line> {
    val page = renderer.openPage(pno)
    val scale = dpi / 72f
    val bmp = Bitmap.createBitmap((page.width * scale).toInt(), (page.height * scale).toInt(), Bitmap.Config.ARGB_8888)
    bmp.eraseColor(Color.WHITE)
    try {
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
    } finally {
        page.close()
    }
    val result = try {
        recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
    } finally {
        bmp.recycle()
    }
    val out = ArrayList<Line>()
    for ((bi, block) in result.textBlocks.withIndex()) {
        val bb = block.boundingBox
        for (ln in block.lines) {
            val r = ln.boundingBox ?: continue
            val text = cleanText(ln.text)
            if (text.isEmpty()) continue
            val h = r.height() / scale
            val line = Line(text, r.left / scale, r.right / scale, r.top / scale, r.bottom / scale, h * 0.8f, false)
            line.block = bi
            if (bb != null) { line.blockX0 = bb.left / scale; line.blockX1 = bb.right / scale }
            out.add(line)
        }
    }
    return out
}

// ----------------------------------------------------------- paragraphs

private val BULLET_RE = Regex("""^\s*(?:[•●▪■◦‣·\-–—*]|\(?\d{1,3}[.)]|\(?[A-Za-z][.)])\s+""")
private val BULLET_STRIP = Regex("""^\s*[•●▪■◦‣·*\-–—]\s+""")
private val END_RE = Regex("""[.!?:;…)”"'\]]\s*$""")

fun stripBullet(s: String) = BULLET_STRIP.replace(s, "")

private fun joinLines(lines: List<String>): String {
    var out = lines[0]
    for (nxt in lines.drop(1)) {
        out = if (out.endsWith("-") && out.length > 1 && out[out.length - 2].isLetter() && nxt.firstOrNull()?.isLowerCase() == true)
            out.dropLast(1) + nxt
        else "$out $nxt"
    }
    return out
}

private fun median(v: List<Float>): Float {
    val s = v.sorted()
    return if (s.isEmpty()) 0f else if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
}

/** PDFs have no paragraphs: rebuild them from block and line geometry. */
fun buildParagraphs(lines: List<Line>, pageNo: Int): List<Para> {
    if (lines.isEmpty()) return emptyList()
    val blocks = lines.groupBy { it.block }.values
    val pitches = ArrayList<Float>()
    for (b in blocks) for (i in 0 until b.size - 1) {
        val p = b[i + 1].top - b[i].top
        if (p > 0f && p < 80f) pitches.add(p)
    }
    val med = if (pitches.isEmpty()) 14f else median(pitches)

    val groups = ArrayList<List<Line>>()
    for (blk in blocks) {
        val bx0 = blk[0].blockX0
        val bx1 = blk[0].blockX1
        var cur = arrayListOf(blk[0])
        for (i in 1 until blk.size) {
            val prev = blk[i - 1]
            val ln = blk[i]
            val fresh = ln.top - prev.top > 1.6f * med ||
                abs(ln.size - prev.size) > 1f ||
                BULLET_RE.containsMatchIn(ln.text) ||
                (ln.x0 - bx0 > 1.2f * ln.size && prev.x1 > bx1 - 2.5f * ln.size)
            if (fresh) { groups.add(cur); cur = ArrayList() }
            cur.add(ln)
        }
        groups.add(cur)
    }
    return groups.map { g ->
        Para(joinLines(g.map { it.text }), median(g.map { it.size }), g.count { it.bold } > g.size / 2, pageNo)
    }
}

/** Mark headings and list items using the document's dominant font size. */
fun classifyParagraphs(paras: List<Para>) {
    if (paras.isEmpty()) return
    val weighted = paras.map { it.size to it.text.length }.sortedBy { it.first }
    val total = weighted.sumOf { it.second }
    var acc = 0
    var body = weighted[0].first
    for ((s, w) in weighted) {
        acc += w
        if (acc >= total / 2.0) { body = s; break }
    }
    for (p in paras) {
        p.kind = when {
            p.size >= body * 1.5f -> "h1"
            p.size >= body * 1.2f -> "h2"
            p.bold && p.text.length < 100 && !END_RE.containsMatchIn(p.text) && p.size >= body * 0.98f -> "h3"
            BULLET_RE.containsMatchIn(p.text) -> "li"
            else -> "p"
        }
    }
}
