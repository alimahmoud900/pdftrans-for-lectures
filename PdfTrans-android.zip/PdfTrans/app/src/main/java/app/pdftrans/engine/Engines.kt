package app.pdftrans.engine

import android.text.Html
import app.pdftrans.AppSettings
import app.pdftrans.EngineKind
import app.pdftrans.PdfTransException
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// ----------------------------------------------------------------------- HTTP

object Http {
    private const val UA = "Mozilla/5.0 (Linux; Android) PdfTrans/1.0"

    fun get(url: String): String = call(url, "GET", null, null)
    fun post(url: String, body: String, contentType: String): String = call(url, "POST", body, contentType)

    private fun call(url: String, method: String, body: String?, contentType: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.setRequestProperty("User-Agent", UA)
            if (body != null) {
                c.doOutput = true
                if (contentType != null) c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code ${text.take(160)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

// ----------------------------------------------------------------- base class

/** Batching, caching, retry with back-off, batch splitting and a circuit breaker. */
abstract class Engine {
    var failed = 0
        private set
    private val cache = HashMap<String, String>()
    private var consecutiveFails = 0

    protected open val maxItems = 20
    protected open val maxChars = 3000
    protected open val retries = 3
    protected open val retryDelayMs = 1500L

    /** Throw [PdfTransException] early if the engine cannot work. */
    open suspend fun prepare() {}
    open fun close() {}
    protected abstract suspend fun translateBatch(texts: List<String>): List<String>

    suspend fun translate(texts: List<String>, progress: (Int, Int) -> Unit): List<String> {
        val out = arrayOfNulls<String>(texts.size)
        val todo = LinkedHashMap<String, MutableList<Int>>()
        texts.forEachIndexed { i, t ->
            val hit = cache[t]
            if (hit != null) out[i] = hit else todo.getOrPut(t) { mutableListOf() }.add(i)
        }
        val uniq = todo.keys.toList()
        var done = 0
        progress(0, uniq.size)
        for (batch in batches(uniq)) {
            currentCoroutineContext().ensureActive()
            val res = safeBatch(batch)
            batch.forEachIndexed { j, t ->
                cache[t] = res[j]
                todo.getValue(t).forEach { out[it] = res[j] }
            }
            done += batch.size
            progress(done, uniq.size)
        }
        return texts.indices.map { out[it] ?: texts[it] }
    }

    private fun batches(items: List<String>): List<List<String>> {
        val all = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        var chars = 0
        for (t in items) {
            if (cur.isNotEmpty() && (cur.size >= maxItems || chars + t.length > maxChars)) {
                all.add(cur); cur = ArrayList(); chars = 0
            }
            cur.add(t); chars += t.length
        }
        if (cur.isNotEmpty()) all.add(cur)
        return all
    }

    private suspend fun safeBatch(batch: List<String>): List<String> {
        var last: Exception? = null
        for (attempt in 0 until retries) {
            try {
                val res = translateBatch(batch)
                check(res.size == batch.size) { "engine returned a wrong number of results" }
                consecutiveFails = 0
                return res.mapIndexed { i, r -> if (r.isNotBlank()) r else batch[i] }
            } catch (e: CancellationException) {
                throw e
            } catch (e: PdfTransException) {
                throw e
            } catch (e: Exception) {
                last = e
                delay(retryDelayMs * (attempt + 1))
            }
        }
        if (batch.size > 1) {
            val mid = batch.size / 2
            return safeBatch(batch.subList(0, mid)) + safeBatch(batch.subList(mid, batch.size))
        }
        failed++
        consecutiveFails++
        if (consecutiveFails >= 4) throw PdfTransException("engine_failing", last?.message ?: "")
        return batch
    }
}

abstract class PerTextEngine : Engine() {
    override val maxItems = 8
    private val gate = Semaphore(4)
    protected abstract suspend fun one(text: String): String

    override suspend fun translateBatch(texts: List<String>): List<String> = coroutineScope {
        texts.map { t -> async { gate.withPermit { one(t) } } }.awaitAll()
    }
}

// ------------------------------------------------------------ on-device engine

object LocalModel {
    private fun model() = TranslateRemoteModel.Builder(TranslateLanguage.ARABIC).build()

    suspend fun isDownloaded(): Boolean = RemoteModelManager.getInstance().isModelDownloaded(model()).await()

    suspend fun download(wifiOnly: Boolean = false) {
        val cond = DownloadConditions.Builder().apply { if (wifiOnly) requireWifi() }.build()
        RemoteModelManager.getInstance().download(model(), cond).await()
    }

    suspend fun delete() {
        RemoteModelManager.getInstance().deleteDownloadedModel(model()).await()
    }
}

/** ML Kit on-device translation: no text leaves the phone once the model is downloaded. */
class MlKitEngine : Engine() {
    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )
    override val maxItems = 10

    override suspend fun prepare() {
        if (!LocalModel.isDownloaded()) throw PdfTransException("model_missing")
    }

    override suspend fun translateBatch(texts: List<String>): List<String> =
        texts.map { translator.translate(it).await() }

    override fun close() = translator.close()
}

// ------------------------------------------------------------- online engines

/** Unofficial Google web endpoint. Opt-in only: may break or violate Google's ToS. */
class GoogleEngine : PerTextEngine() {
    override suspend fun one(text: String): String {
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t"
        val body = withContext(Dispatchers.IO) {
            Http.post(url, "q=" + enc(text), "application/x-www-form-urlencoded; charset=UTF-8")
        }
        val arr = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val seg = arr.optJSONArray(i) ?: continue
            if (!seg.isNull(0)) sb.append(seg.getString(0))
        }
        delay(80)
        return sb.toString()
    }
}

/** MyMemory: official free API. ~5k chars/day anonymous, ~50k/day when an email is supplied. */
class MyMemoryEngine(private val email: String) : PerTextEngine() {
    private fun chunk(text: String, limit: Int = 450): List<String> {
        if (text.length <= limit) return listOf(text)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (sentence in text.split(Regex("(?<=[.!?;:])\\s+"))) {
            if (sb.isNotEmpty() && sb.length + sentence.length + 1 > limit) { out.add(sb.toString()); sb.clear() }
            if (sentence.length > limit) { sentence.chunked(limit).forEach { out.add(it) }; continue }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sentence)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    override suspend fun one(text: String): String {
        val parts = chunk(text).map { part ->
            var url = "https://api.mymemory.translated.net/get?q=${enc(part)}&langpair=en%7Car"
            if (email.isNotBlank()) url += "&de=${enc(email.trim())}"
            val json = JSONObject(withContext(Dispatchers.IO) { Http.get(url) })
            val status = json.opt("responseStatus")?.toString()
            var tt = json.optJSONObject("responseData")?.optString("translatedText").orEmpty()
            if (status == "429" || tt.contains("MYMEMORY WARNING", ignoreCase = true)) throw PdfTransException("quota")
            if (status != "200") throw IOException("MyMemory status $status")
            if (tt.contains('&')) {
                tt = Html.fromHtml(tt, Html.FROM_HTML_MODE_LEGACY).toString()
            }
            tt
        }
        return parts.joinToString(" ")
    }
}

/** Self-hosted (or any) LibreTranslate server. */
class LibreEngine(url: String, private val key: String) : Engine() {
    private val base = url.trim().trimEnd('/')
    override val maxItems = 30

    override suspend fun translateBatch(texts: List<String>): List<String> {
        val payload = JSONObject()
            .put("q", JSONArray(texts)).put("source", "en").put("target", "ar").put("format", "text")
        if (key.isNotBlank()) payload.put("api_key", key.trim())
        val body = withContext(Dispatchers.IO) { Http.post("$base/translate", payload.toString(), "application/json") }
        val t = JSONObject(body).get("translatedText")
        return if (t is JSONArray) List(t.length()) { t.getString(it) } else listOf(t.toString())
    }
}

fun makeEngine(s: AppSettings): Engine = when (s.engine) {
    EngineKind.ONDEVICE -> MlKitEngine()
    EngineKind.GOOGLE -> {
        if (!s.allowGoogle) throw PdfTransException("google_optin")
        GoogleEngine()
    }
    EngineKind.MYMEMORY -> MyMemoryEngine(s.memoryEmail)
    EngineKind.LIBRE -> {
        if (s.libreUrl.isBlank()) throw PdfTransException("libre_url")
        LibreEngine(s.libreUrl, s.libreKey)
    }
}
